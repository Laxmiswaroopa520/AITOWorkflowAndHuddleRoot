﻿/*
    Segments, roles, segment roles, focus areas and MCEM stages
    Generated from the Frontier Accelerator content workbook by generate.py.
    Do not hand-edit. Re-runnable: every statement is an ExternalId-keyed MERGE, nothing is deleted.
*/
/* ---------------------------------------------------------------------------------------------
   MERGED for fresh-install-v11.78 (2026-09-16): this script now also contains the new-only
   Huddle rows identified by comparing the 9.15.2026 Frontier Accelerator workbook against the
   V10.2.1 workbook this folder was originally built from. Every row already present in
   fresh-install-v10.2.1 is untouched; only rows verified absent from that baseline were appended,
   using the same ExternalId-keyed MERGE already in this file. See the new 00_README_Fresh_Install.md
   in this folder for the full merge report and the list of items deliberately NOT included.
   --------------------------------------------------------------------------------------------- */

SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @unresolved INT;
BEGIN TRANSACTION;

-- Segments
;WITH raw AS (
    SELECT * FROM (VALUES
        (N'SEG-ENT', N'Enterprise'),
        (N'SEG-SMEC', N'SME&C')
    ) v([ExternalId], [Name])
), src AS (
    SELECT raw.*
    FROM raw
)
MERGE dbo.HuddleSegments AS tgt
USING src ON tgt.[ExternalId] = src.[ExternalId]
WHEN MATCHED THEN UPDATE SET
        tgt.[Name] = src.[Name],
        tgt.[UpdatedAtUtc] = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN INSERT ([ExternalId], [Name], [CreatedAtUtc])
    VALUES (src.[ExternalId], src.[Name], SYSUTCDATETIME());

-- Roles. Segment is denormalised onto Role; a role spanning multiple segments keeps the
-- segment it first appears under in Segment_Roles (see comment above).
;WITH raw AS (
    SELECT * FROM (VALUES
        (N'ROLE-AE', N'Account Executive', N'AE', N'Enterprise', 1, 1),
        (N'ROLE-ATS', N'Account Technology Strategist', N'ATS', N'Enterprise', 2, 1),
        (N'ROLE-SSP', N'Solution Sales Professional', N'SSP', N'Enterprise', 3, 1),
        (N'ROLE-SE', N'Solution Engineer', N'SE', N'Enterprise', 4, 1),
        (N'ROLE-CE', N'Commercial Executive', N'CE', N'Enterprise', 5, 1),
        (N'ROLE-CSA', N'Cloud Solution Architect', N'CSA', N'Enterprise', 6, 1),
        (N'ROLE-CSAM', N'Customer Success Account Manager', N'CSAM', N'Enterprise', 7, 1),
        (N'ROLE-ALL', N'All Roles', N'ALL', N'Enterprise', 8, 1),
        (N'ROLE-DAE', N'Digital Account Executive', N'DAE', N'SME&C', 9, 1),
        (N'ROLE-DSS', N'Digital Solution Area Specialist', N'DSS', N'SME&C', 10, 1),
        (N'ROLE-DSE', N'Digital Solution Engineer', N'DSE', N'SME&C', 11, 1),
        (N'ROLE-DCSA', N'Digital Cloud Solution Architect', N'DCSA', N'SME&C', 12, 1),
        (N'ROLE-PSS', N'Partner Solution Sales', N'PSS', N'SME&C', 13, 1)
    ,
        (N'ROLE-SMEC-CE', N'Commercial Executive (SME&C)', N'SMEC-CE', N'SME&C', 14, 1)) v([ExternalId], [Name], [Abbreviation], [Segment], [SortOrder], [IsActive])
), src AS (
    SELECT raw.*
    FROM raw
)
MERGE dbo.Roles AS tgt
USING src ON tgt.[ExternalId] = src.[ExternalId]
WHEN MATCHED THEN UPDATE SET
        tgt.[Name] = src.[Name],
        tgt.[Abbreviation] = src.[Abbreviation],
        tgt.[Segment] = src.[Segment],
        tgt.[SortOrder] = src.[SortOrder],
        tgt.[IsActive] = src.[IsActive],
        tgt.[UpdatedAtUtc] = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN INSERT ([ExternalId], [Name], [Abbreviation], [Segment], [SortOrder], [IsActive], [CreatedAtUtc])
    VALUES (src.[ExternalId], src.[Name], src.[Abbreviation], src.[Segment], src.[SortOrder], src.[IsActive], SYSUTCDATETIME());

-- Segment roles
;WITH raw AS (
    SELECT * FROM (VALUES
        (N'SR-ENT-AE', N'SEG-ENT', N'ROLE-AE', N'Account Executive'),
        (N'SR-ENT-ATS', N'SEG-ENT', N'ROLE-ATS', N'Account Technology Strategist'),
        (N'SR-ENT-SSP', N'SEG-ENT', N'ROLE-SSP', N'Solution Sales Professional'),
        (N'SR-ENT-SE', N'SEG-ENT', N'ROLE-SE', N'Solution Engineer'),
        (N'SR-ENT-CE', N'SEG-ENT', N'ROLE-CE', N'Commercial Executive'),
        (N'SR-ENT-CSA', N'SEG-ENT', N'ROLE-CSA', N'Cloud Solution Architect'),
        (N'SR-ENT-CSAM', N'SEG-ENT', N'ROLE-CSAM', N'Customer Success Account Manager'),
        (N'SR-ENT-ALL', N'SEG-ENT', N'ROLE-ALL', N'All Roles'),
        (N'SR-SMEC-DAE', N'SEG-SMEC', N'ROLE-DAE', N'Digital Account Executive'),
        (N'SR-SMEC-CE', N'SEG-SMEC', N'ROLE-CE', N'Commercial Executive'),
        (N'SR-SMEC-DSS', N'SEG-SMEC', N'ROLE-DSS', N'Digital Solution Area Specialist'),
        (N'SR-SMEC-DSE', N'SEG-SMEC', N'ROLE-DSE', N'Digital Solution Engineer'),
        (N'SR-SMEC-DCSA', N'SEG-SMEC', N'ROLE-DCSA', N'Digital Cloud Solution Architect'),
        (N'SR-SMEC-PSS', N'SEG-SMEC', N'ROLE-PSS', N'Partner Solution Sales'),
        (N'SR-SMEC-ALL', N'SEG-SMEC', N'ROLE-ALL', N'All Roles')
    ) v([ExternalId], [SegmentExternalId], [RoleExternalId], [DisplayName])
), src AS (
    SELECT raw.*, sg.Id AS [HuddleSegmentId], rl.Id AS [RoleId]
    FROM raw
    INNER JOIN dbo.HuddleSegments AS sg ON sg.[ExternalId] = raw.[SegmentExternalId]
    INNER JOIN dbo.Roles AS rl ON rl.[ExternalId] = raw.[RoleExternalId]
)
MERGE dbo.HuddleSegmentRoles AS tgt
USING src ON tgt.[ExternalId] = src.[ExternalId]
WHEN MATCHED THEN UPDATE SET
        tgt.[HuddleSegmentId] = src.[HuddleSegmentId],
        tgt.[RoleId] = src.[RoleId],
        tgt.[DisplayName] = src.[DisplayName],
        tgt.[UpdatedAtUtc] = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN INSERT ([ExternalId], [HuddleSegmentId], [RoleId], [DisplayName], [CreatedAtUtc])
    VALUES (src.[ExternalId], src.[HuddleSegmentId], src.[RoleId], src.[DisplayName], SYSUTCDATETIME());
;WITH raw AS (
    SELECT * FROM (VALUES
        (N'SR-ENT-AE', N'SEG-ENT', N'ROLE-AE', N'Account Executive'),
        (N'SR-ENT-ATS', N'SEG-ENT', N'ROLE-ATS', N'Account Technology Strategist'),
        (N'SR-ENT-SSP', N'SEG-ENT', N'ROLE-SSP', N'Solution Sales Professional'),
        (N'SR-ENT-SE', N'SEG-ENT', N'ROLE-SE', N'Solution Engineer'),
        (N'SR-ENT-CE', N'SEG-ENT', N'ROLE-CE', N'Commercial Executive'),
        (N'SR-ENT-CSA', N'SEG-ENT', N'ROLE-CSA', N'Cloud Solution Architect'),
        (N'SR-ENT-CSAM', N'SEG-ENT', N'ROLE-CSAM', N'Customer Success Account Manager'),
        (N'SR-ENT-ALL', N'SEG-ENT', N'ROLE-ALL', N'All Roles'),
        (N'SR-SMEC-DAE', N'SEG-SMEC', N'ROLE-DAE', N'Digital Account Executive'),
        (N'SR-SMEC-CE', N'SEG-SMEC', N'ROLE-CE', N'Commercial Executive'),
        (N'SR-SMEC-DSS', N'SEG-SMEC', N'ROLE-DSS', N'Digital Solution Area Specialist'),
        (N'SR-SMEC-DSE', N'SEG-SMEC', N'ROLE-DSE', N'Digital Solution Engineer'),
        (N'SR-SMEC-DCSA', N'SEG-SMEC', N'ROLE-DCSA', N'Digital Cloud Solution Architect'),
        (N'SR-SMEC-PSS', N'SEG-SMEC', N'ROLE-PSS', N'Partner Solution Sales'),
        (N'SR-SMEC-ALL', N'SEG-SMEC', N'ROLE-ALL', N'All Roles')
    ) v([ExternalId], [SegmentExternalId], [RoleExternalId], [DisplayName])
)
SELECT @unresolved = 15 - COUNT(*) FROM raw
    INNER JOIN dbo.HuddleSegments AS sg ON sg.[ExternalId] = raw.[SegmentExternalId]
    INNER JOIN dbo.Roles AS rl ON rl.[ExternalId] = raw.[RoleExternalId];
IF @unresolved <> 0
    THROW 51000, 'HuddleSegmentRoles: 15 source rows were expected to resolve their foreign keys but some did not. Run the earlier scripts in order and re-check the workbook.', 1;

-- Focus areas
;WITH raw AS (
    SELECT * FROM (VALUES
        (N'FA-01', N'Pipeline and Opportunity'),
        (N'FA-02', N'Customer Engagement and Value'),
        (N'FA-03', N'Solution and Deal Strategy'),
        (N'FA-04', N'Commercial Execution'),
        (N'FA-05', N'Technical Solutioning'),
        (N'FA-06', N'Customer Success and Technical Health'),
        (N'FA-07', N'Orchestration and Investment'),
        (N'FA-00', N'Foundation and Orientation')
    ) v([ExternalId], [Name])
), src AS (
    SELECT raw.*
    FROM raw
)
MERGE dbo.HuddleFocusAreas AS tgt
USING src ON tgt.[ExternalId] = src.[ExternalId]
WHEN MATCHED THEN UPDATE SET
        tgt.[Name] = src.[Name],
        tgt.[UpdatedAtUtc] = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN INSERT ([ExternalId], [Name], [CreatedAtUtc])
    VALUES (src.[ExternalId], src.[Name], SYSUTCDATETIME());

-- MCEM stages. StageNumber is stored now rather than parsed out of the ExternalId.
;WITH raw AS (
    SELECT * FROM (VALUES
        (N'MCEM-01', N'Listen and Consult', N'Understand the customer''s business, goals, challenges and priorities.', 1),
        (N'MCEM-02', N'Inspire and Design', N'Show what''s possible, envision solutions, create strategy and design.', 2),
        (N'MCEM-03', N'Empower and Achieve', N'Implement, deploy, enable users, drive adoption and start achieving value.', 3),
        (N'MCEM-04', N'Realize Value', N'Measure results, demonstrate business impact and validate success.', 4),
        (N'MCEM-05', N'Manage and Optimize', N'Continuously improve, optimise usage, expand adoption and identify new opportunities.', 5)
    ) v([ExternalId], [Name], [Description], [StageNumber])
), src AS (
    SELECT raw.*
    FROM raw
)
MERGE dbo.HuddleMcemStages AS tgt
USING src ON tgt.[ExternalId] = src.[ExternalId]
WHEN MATCHED THEN UPDATE SET
        tgt.[Name] = src.[Name],
        tgt.[Description] = src.[Description],
        tgt.[StageNumber] = src.[StageNumber],
        tgt.[UpdatedAtUtc] = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN INSERT ([ExternalId], [Name], [Description], [StageNumber], [CreatedAtUtc])
    VALUES (src.[ExternalId], src.[Name], src.[Description], src.[StageNumber], SYSUTCDATETIME());

COMMIT TRANSACTION;
GO
